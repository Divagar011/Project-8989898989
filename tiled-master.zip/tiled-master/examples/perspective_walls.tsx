<?xml version="1.0" encoding="UTF-8"?>
<tileset name="perspective_walls" tilewidth="64" tileheight="64">
 <tileoffset x="-32" y="0"/>
 <image source="perspective_walls.png"/>
 <tile id="13">
  <properties>
   <property name="door" value="true"/>
  </properties>
 </tile>
 <tile id="14">
  <properties>
   <property name="door" value="true"/>
  </properties>
 </tile>
 <tile id="15">
  <properties>
   <property name="pickup" value="true"/>
  </properties>
 </tile>
</tileset>
