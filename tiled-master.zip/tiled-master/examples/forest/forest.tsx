<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="forest" tilewidth="160" tileheight="208" tilecount="7" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0" x="1" y="1" width="16" height="16">
  <image width="1024" height="1024" source="squirrel.png"/>
 </tile>
 <tile id="6" x="521" y="114" width="160" height="208">
  <image width="1024" height="1024" source="squirrel.png"/>
 </tile>
 <tile id="8" x="682" y="1" width="160" height="112">
  <image width="1024" height="1024" source="squirrel.png"/>
 </tile>
 <tile id="9" x="521" y="1" width="160" height="112">
  <image width="1024" height="1024" source="squirrel.png"/>
 </tile>
 <tile id="10" x="116" y="824" width="25" height="25">
  <image width="1024" height="1024" source="squirrel.png"/>
 </tile>
 <tile id="11" x="116" y="850" width="25" height="25">
  <image width="1024" height="1024" source="squirrel.png"/>
 </tile>
 <tile id="13" x="116" y="824" width="25" height="25">
  <image width="1024" height="1024" source="squirrel.png"/>
  <animation>
   <frame tileid="10" duration="150"/>
   <frame tileid="11" duration="150"/>
  </animation>
 </tile>
</tileset>
